const request = require('supertest');
const app = require('../index.js');

describe('Calculadora API', () => {
    // Teste para a rota raiz
    it('deve retornar "Hello Word" para a rota raiz', async () => {
        const response = await request(app).get('/');
        expect(response.statusCode).toBe(200);
        expect(response.text).toBe('Hello Word');
    });

      // Teste para a operação de soma
      it('deve retornar a soma de dois números', async () => {
        const response = await request(app)
            .get('/calculadora')
            .query({ numero1: 5, numero2: 3, operacao: 'soma' });
        expect(response.statusCode).toBe(200);
        expect(response.body).toEqual({ resultado: 8 });
    });

    // Teste para a operação de subtração
    it('deve retornar a subtração de dois números', async () => {
        const response = await request(app)
            .get('/calculadora')
            .query({ numero1: 5, numero2: 3, operacao: 'subtracao' });
        expect(response.statusCode).toBe(200);
        expect(response.body).toEqual({ resultado: 2 });
    });

    // Teste para a operação de multiplicação
    it('deve retornar a multiplicação de dois números', async () => {
        const response = await request(app)
            .get('/calculadora')
            .query({ numero1: 5, numero2: 3, operacao: 'multiplicacao' });
        expect(response.statusCode).toBe(200);
        expect(response.body).toEqual({ resultado: 15 });
    });

    
    // Teste para a operação de divisão
    it('deve retornar a divisão de dois números', async () => {
        const response = await request(app)
            .get('/calculadora')
            .query({ numero1: 4, numero2: 2, operacao: 'divisao' });
        expect(response.statusCode).toBe(200);
        expect(response.body).toEqual({ resultado: 2 });
    });

     // Teste para a operação de divisão por 0
     it('deve retornar a divisão números por 0 ', async () => {
        const response = await request(app)
            .get('/calculadora')
            .query({ numero1: 4, numero2: 0, operacao: 'divisao' });
        expect(response.statusCode).toBe(400);
        expect(response.body).toEqual({ erro: 'Divisão por zero não é permitida' });
    });


    




});